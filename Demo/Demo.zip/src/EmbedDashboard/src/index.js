import DashIframe from './components/DashIframe';

export { DashIframe };