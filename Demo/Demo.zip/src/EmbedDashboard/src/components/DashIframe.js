import { useEffect, useMemo } from 'react';
import { embedDashboard } from '../utils/embedDashboard';

function DashIframe({ dashboardId, userDetails, accountRoleInfo }) {
  const { username, first_name, last_name } = userDetails;
  const { account, role } = accountRoleInfo;

  // Memoize dependencies to prevent unnecessary re-renders
  const memoizedUserDetails = useMemo(() => ({ username, first_name, last_name }), [username, first_name, last_name]);
  const memoizedAccountRoleInfo = useMemo(() => ({ account, role }), [account, role]);

  const getToken = async () => {
    const response = await fetch("http://localhost:3001/guest-token", {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        dashboardId, // Include dashboardId in the request body
        userDetails: memoizedUserDetails,
        accountRoleInfo: memoizedAccountRoleInfo,
      }),
    });
    const data = await response.json();
    const token = data.token;
    console.log('Received guest token:', token);
    return token;
  };

  useEffect(() => {
    const embed = async () => {
      await embedDashboard({
        id: dashboardId,
        DashboardDomain: process.env.REACT_APP_DASHBOARD_DOMAIN,
        mountPoint: document.getElementById('dashboard'),
        fetchGuestToken: () => getToken(),
        dashboardUiConfig: {
          hideTitle: true,
          hideChartControls: true,
          hideTab: true,
          filters: {
            expanded: false,
          },
        },
      });
    };

    if (document.getElementById('dashboard')) {
      embed();
    }
  }, [dashboardId, memoizedUserDetails, memoizedAccountRoleInfo]);

  return (
      <div id="dashboard"></div>
  );
}

export default DashIframe;