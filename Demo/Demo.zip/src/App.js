import React, { useMemo } from 'react';
import DashIframe from './EmbedDashboard/src/components/DashIframe';



function App() {
  const userDetails = useMemo(() => ({
    username: 'john_doe',
    first_name: 'John',
    last_name: 'Doe',
  }), []);
  
  const accountRoleInfo = useMemo(() => ({
    account: 'IT',
    role: 'Admin',
  }), []);
  
  return (
    <DashIframe
      dashboardId={process.env.REACT_APP_DASHBOARD_ID_1}
      userDetails={userDetails}
      accountRoleInfo={accountRoleInfo}
    />
  );
}

export default App;